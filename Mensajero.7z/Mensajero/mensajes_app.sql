-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 18-05-2022 a las 22:05:28
-- Versión del servidor: 5.6.17
-- Versión de PHP: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `mensajes`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mensajes`
--

CREATE TABLE IF NOT EXISTS `mensajes` (
  `id_mensaje` int(7) NOT NULL AUTO_INCREMENT,
  `mensaje` varchar(280) NOT NULL,
  `autor_mensaje` varchar(50) NOT NULL,
  `asunto` varchar(80) NOT NULL,
  `fecha_mensaje` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_mensaje`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=29 ;

--
-- Volcado de datos para la tabla `mensajes`
--

INSERT INTO `mensajes` (`id_mensaje`, `mensaje`, `autor_mensaje`, `asunto`, `fecha_mensaje`) VALUES
(1, 'Mientras haya vida, hay esperanza', 'Laura', 'Reflexión', '2022-05-13 14:01:48'),
(9, 'Soy fan de los perros', 'Laura Ache', 'Pensamiento', '2022-05-13 14:01:55'),
(11, 'Me pides que sigamos siendo amigos', 'Miguel', 'Frase', '2022-05-13 14:02:01'),
(12, '¿Amigos para qué?, ¡maldita sea!', 'Miguel', 'Canción', '2022-05-13 14:03:26'),
(18, 'Lenguajes como PHP, Java, Python', 'Miguel Soto', 'Progra', '2022-05-18 18:42:17'),
(19, 'Lenguajes, automatas, inteligencia artificial', 'Miguel Soto', 'Gramaticas', '2022-05-18 18:42:45'),
(20, 'El pH signfica potencial de Hidrogeno', 'Miguel Soto', 'Biología', '2022-05-18 18:44:17'),
(21, 'Como hago para saldar una cuenta con partida doble ??', 'Miguel Soto', 'Contabilidad', '2022-05-18 18:44:51'),
(22, 'Hay que usar los conocimientos de Lucas Pacioli', 'Miguel Soto', 'RE: Contabilidad', '2022-05-18 18:45:40'),
(23, 'de la enesima prueba\n', 'Miguel Soto', 'Prueba', '2022-05-18 19:53:55'),
(24, 'atención deficiente', 'Miguel Soto', 'KTM', '2022-05-18 19:58:12'),
(25, 'mala atención', 'Miguel Soto', 'auteco', '2022-05-18 19:58:20'),
(26, 'saluda como debe ser', 'Miguel Soto', 'prueba saludos', '2022-05-18 20:01:10'),
(27, 'juego de disparos en rusia', 'Miguel Soto', 'Metro Redux', '2022-05-18 20:01:59'),
(28, 'La prueba mas prueba de todas las pruebas', 'Miguel Soto', 'Prueba enesima', '2022-05-18 20:03:31');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(70) NOT NULL,
  `clave` varchar(70) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `usuario`, `clave`, `nombre`) VALUES
(1, 'miguel', 'mas123', 'Miguel Soto'),
(2, 'laura', 'lh123', 'Laura Herrera');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
