package mensajero;

import Controladores.ControlLogin;
import Vistas.VistaLogin;
import Modelos.ModelLogin;
import Modelos.Conexion;
import java.sql.SQLException;

public class Mensajero {

    public static void main(String[] args) throws SQLException {
       ModelLogin modelo = new ModelLogin();
       VistaLogin vista = new VistaLogin();
       Conexion conex = new Conexion();
       
       ControlLogin control = new ControlLogin(modelo ,vista, conex);
       control.inicio();
       vista.setVisible(true);
    }
}
