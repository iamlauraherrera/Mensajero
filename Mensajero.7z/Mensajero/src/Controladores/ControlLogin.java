package Controladores;

import Vistas.VistaLogin;
import Modelos.ModelLogin;
import Modelos.Conexion;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.sql.SQLException;

public class ControlLogin implements ActionListener, KeyListener{
    ModelLogin modelo;
    VistaLogin vista;
    Conexion conex;

    public ControlLogin(){}

    public ControlLogin(ModelLogin modelo, VistaLogin vista, Conexion conex) {
        this.modelo = modelo;
        this.vista = vista;
        this.conex = conex;
        this.vista.btnIngreso.addActionListener(this);
        this.vista.btnLimpiar.addActionListener(this);
        this.vista.clave.addActionListener(this);
        this.vista.usuario.addActionListener(this);
        this.vista.usuario.addKeyListener(this);
        this.vista.clave.addKeyListener(this);
    }
    
    public void actionperformed(ActionEvent e){}
    
    public void inicio() throws SQLException {
        vista.setTitle("Login");
        vista.setLocationRelativeTo( null);
        vista.setVisible(true);
    }
    
    // Validar el login tambien con la tecla enter
    // En cualquiera de los dos inputs
    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_ENTER){
            modelo.setUsuario(vista.usuario.getText());
            modelo.setClave(vista.clave.getText());
            modelo.consultarUsuario();
        }
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        
        // Manejar las acciones del login
        // Dependiendo del botón que haga click
        if (e.getSource() == vista.btnIngreso){
            modelo.setUsuario(vista.usuario.getText());
            modelo.setClave(vista.clave.getText());
            modelo.consultarUsuario();
        }
        
        if (e.getSource() == vista.btnLimpiar){
            vista.clave.setText("");
            vista.usuario.setText("");
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
        
    }

    @Override
    public void keyReleased(KeyEvent e) {
        
    }
}
