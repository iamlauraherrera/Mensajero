package Controladores;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import Modelos.ModelInsert;
import Vistas.VistaInsert;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ControlInsert implements ActionListener{
    String user;
    ModelInsert modelo;
    VistaInsert vista;
    
    public ControlInsert(){}

    public ControlInsert(ModelInsert modelo, VistaInsert vista, String user) {
        this.modelo = modelo;
        this.vista = vista;
        this.user = user;
        this.vista.btnCancel.addActionListener(this);
        this.vista.btnGuardar.addActionListener(this);
        this.vista.btnRegresar.addActionListener(this);
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }
    
    public void inicio(){
        vista.setTitle("Nuevo mensaje");
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        // Guardar los datos en la tabla
        if (e.getSource() == vista.btnGuardar){
            try {
                // Mandar los valores obtenidos de la vista al modelo
                modelo.setAsunto(vista.asunto.getText());
                modelo.setMensaje(vista.mensaje.getText());
                modelo.setUsuario(this.getUser());
                modelo.insertarMensaje();
                
                // Limpiar los campos de la vista
                vista.asunto.setText("");
                vista.mensaje.setText("");
            } catch (SQLException ex) {
                Logger.getLogger(ControlInsert.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        // Limpiar el formulario
        if (e.getSource() == vista.btnCancel){
            vista.asunto.setText("");
            vista.mensaje.setText("");
        }
        
        // Regresar al menu principal
        if (e.getSource() == vista.btnRegresar){
            vista.setVisible(false);
        }
    }
    
}
