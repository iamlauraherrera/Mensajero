package Controladores;

import Modelos.ModelBorrar;
import Vistas.VistaBorrar;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ControlBorrar implements ActionListener{
    ModelBorrar modelo;
    VistaBorrar vista;
    
    public ControlBorrar(){}

    public ControlBorrar(ModelBorrar modelo, VistaBorrar vista) {
        this.modelo = modelo;
        this.vista = vista;
        this.vista.btnBorrar.addActionListener(this);
        this.vista.btnCancelar.addActionListener(this);
        this.vista.btnRegresar.addActionListener(this);
    }
    
    public void inicio(){
        vista.setTitle("Borrar Mensaje");
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        // Por aqui se ejecuta el delete query
        if (e.getSource() == vista.btnBorrar){
            try {
                modelo.setId(Integer.parseInt(vista.id.getText()));
                modelo.borrarMensaje();
                
                vista.id.setText("");
            } catch (SQLException ex) {
                Logger.getLogger(ControlBorrar.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        // Aqui limpia el formulario
        if (e.getSource() == vista.btnCancelar){
            vista.id.setText("");
        }
        
        // Regresar al menu principal
        if (e.getSource() == vista.btnRegresar){
            vista.setVisible(false);
        }
    }
}
