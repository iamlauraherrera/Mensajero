package Controladores;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import Vistas.VistaEditar;
import Modelos.ModelEditar;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ControlEditar implements ActionListener{
    VistaEditar vista;
    ModelEditar modelo;
    
    public ControlEditar(){}

    public ControlEditar(VistaEditar vista, ModelEditar modelo) {
        this.vista = vista;
        this.modelo = modelo;
        this.vista.btnCancelar.addActionListener(this);
        this.vista.btnGuardar.addActionListener(this);
        this.vista.btnRegresar.addActionListener(this);
    }

    public void inicio(){
        vista.setTitle("Editar Mensaje");
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        // Por aqui se ejecuta el delete query
        if (e.getSource() == vista.btnGuardar){
            try {
                // Asignar los valores a cada variable del modelo, traídos de la vista
                modelo.setAsunto(vista.asunto.getText());
                modelo.setId(Integer.parseInt(vista.id.getText()));
                modelo.setMensaje(vista.mensaje.getText());
                
                modelo.editarMensaje();
                
                vista.id.setText("");
                vista.asunto.setText("");
                vista.mensaje.setText("");
            } catch (SQLException ex) {
                Logger.getLogger(ControlBorrar.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        if(e.getSource() == vista.btnCancelar){
            vista.id.setText("");
            vista.asunto.setText("");
            vista.mensaje.setText("");
        }
        
        if(e.getSource() == vista.btnRegresar){
            vista.setVisible(false);
        }
    }
    
}
