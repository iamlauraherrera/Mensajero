package Controladores;

import Modelos.ModelConsulta;
import Vistas.VistaConsulta;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ControlConsulta implements ActionListener {
    ModelConsulta modelo;
    VistaConsulta vista;
    
    public ControlConsulta(){}

    public ControlConsulta(ModelConsulta modelo, VistaConsulta vista) throws SQLException {
        this.modelo = modelo;
        this.vista = vista;
        
        // Agrego el listener para poder capturar el evento click del boton regresar
        this.vista.btnRegresar.addActionListener(this);
    }

    public ModelConsulta getModelo() {
        return modelo;
    }

    public void setModelo(ModelConsulta modelo) {
        this.modelo = modelo;
    }

    public VistaConsulta getVista() {
        return vista;
    }

    public void setVista(VistaConsulta vista) {
        this.vista = vista;
    }
    
    // Funcion para mostrar la vista de CONSULTA
    public void inicio(){
        vista.setTitle("Consultar");
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
        
        try {
            // Aquí ejecuto directamente la query de todos los mensajes creados
            modelo.setVista(vista);
            modelo.consultarMensajes();
        } catch (SQLException ex) {
            Logger.getLogger(ControlConsulta.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        
        // Controlar el regreso al menu con la opcion regresar
        if(e.getSource() == vista.btnRegresar){
            vista.setVisible(false);
        }
    }
    
}
