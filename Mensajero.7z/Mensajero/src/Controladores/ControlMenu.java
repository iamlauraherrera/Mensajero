package Controladores;

import Modelos.ModelConsulta;
import Modelos.ModelInsert;
import Modelos.ModelEditar;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import Modelos.ModelMenu;
import Modelos.ModelBorrar;
import Vistas.VistaMenu;
import Vistas.VistaConsulta;
import Vistas.VistaInsert;
import Vistas.VistaBorrar;
import Vistas.VistaEditar;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ControlMenu implements ActionListener {
    ModelMenu modelo;
    VistaMenu vista;
    
    public ControlMenu(){}

    public ControlMenu(ModelMenu modelo, VistaMenu vista) {
        this.modelo = modelo;
        this.vista = vista;
        this.vista.btnActualizar.addActionListener(this);
        this.vista.btnConsulta.addActionListener(this);
        this.vista.btnDelete.addActionListener(this);
        this.vista.btnInsert.addActionListener(this);
    }

    public void inicio(){
        vista.setTitle("Menú Principal");
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
        vista.txtUsuario.setText("Bienvenid(o/a): "+modelo.getNombre());
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        // Aquí se desglosan las acciones CRUD del programa
        // Cada opcion del menú llama a una vista diferente
        
        // CREATE ************************************ //
        if (e.getSource() == vista.btnInsert){
            VistaInsert vistaInsert = new VistaInsert();
            ModelInsert modeloInsert = new ModelInsert();
            
            ControlInsert controlInsert = new ControlInsert(modeloInsert, vistaInsert, modelo.getNombre());
            controlInsert.inicio();
            vistaInsert.setVisible(true);
        }
        // READ ************************************** //
        if (e.getSource() == vista.btnConsulta){
            try {
                VistaConsulta vistaConsulta = new VistaConsulta();
                ModelConsulta modeloConsulta = new ModelConsulta();
                
                ControlConsulta controlConsulta = new ControlConsulta(modeloConsulta, vistaConsulta);
                controlConsulta.inicio();
                vistaConsulta.setVisible(true);
            } catch (SQLException ex) {
                Logger.getLogger(ControlMenu.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        // UPDATE ************************************ //
        if (e.getSource() == vista.btnActualizar){
            VistaEditar vistaEditar = new VistaEditar();
            ModelEditar modeloEditar = new ModelEditar();
            
            ControlEditar controlEditar = new ControlEditar(vistaEditar, modeloEditar);
            controlEditar.inicio();
            vistaEditar.setVisible(true);
        }
        // DELETE ************************************ //
        if (e.getSource() == vista.btnDelete){
            VistaBorrar vistaBorrar = new VistaBorrar();
            ModelBorrar modeloBorrar = new ModelBorrar();
            
            ControlBorrar controlBorrar = new ControlBorrar(modeloBorrar, vistaBorrar);
            controlBorrar.inicio();
            vistaBorrar.setVisible(true);
        }
    }
    
}
