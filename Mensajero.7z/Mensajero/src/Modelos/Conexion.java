package Modelos;

import java.sql.*;
import javax.swing.JOptionPane;
import java.sql.DriverManager;

public class Conexion {
    Connection Conex;
    
    public Connection base_datos() throws SQLException {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Conex = DriverManager.getConnection("jdbc:mysql://localhost/mensajes_app","root","");
        }
        catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Error de conexión con el servidor");
        }
        return Conex;
    }
}
