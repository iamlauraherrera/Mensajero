package Modelos;

import Controladores.ControlMenu;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import Vistas.VistaMenu;

public class ModelLogin {
    public String usuario, clave;
    public Connection conex;
    
    public ModelLogin(){}

    public ModelLogin(String usuario, String clave, Connection conex) {
        this.usuario = usuario;
        this.clave = clave;
        this.conex = conex;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }
    
    public void consultarUsuario() {
        try {
            // Aquí llamamos a la clase de conexión creada
            // Para evitar repetir la cadena en cada clase
            Conexion con = new Conexion();
            
            Statement estado = con.base_datos().createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
            ResultSet resultado = estado.executeQuery("SELECT * FROM usuarios WHERE usuario = '"+this.getUsuario()+"' AND clave='"+this.getClave()+"'");
            
            if(resultado.first()) {
                JOptionPane.showMessageDialog(null, "Login exitoso", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
                
                // LLamar a la vista del menú principal
                VistaMenu menu = new VistaMenu();
                ModelMenu modelo = new ModelMenu();
                modelo.setNombre(resultado.getString("nombre"));
                ControlMenu control = new ControlMenu(modelo, menu);
                
                control.inicio();
                menu.setVisible(true);
            }
            else {
                JOptionPane.showMessageDialog(null, "El usuario ingresado no existe", "Mensaje", JOptionPane.ERROR_MESSAGE);
            }
        }
        catch(SQLException e){
            System.out.println("Se ha encontrado el siguiente error: "+ e.getMessage());
        }
    }
}
