package Modelos;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import Vistas.VistaConsulta;

public class ModelConsulta {
    public Connection conex;
    public VistaConsulta vista;
    
    public ModelConsulta(){}

    public ModelConsulta(Connection conex, VistaConsulta vista) {
        this.conex = conex;
        this.vista = vista;
    }

    public Connection getConex() {
        return conex;
    }

    public void setConex(Connection conex) {
        this.conex = conex;
    }

    public VistaConsulta getVista() {
        return vista;
    }

    public void setVista(VistaConsulta vista) {
        this.vista = vista;
    }
    
    public void consultarMensajes() throws SQLException{
        Conexion con = new Conexion();
        
        // Primero hay que contar la cantidad de registros que hay en la tabla
        // Para que la tabla maneje el tamaño dinamicamente
        Statement estadoCount = con.base_datos().createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
        ResultSet resulCount = estadoCount.executeQuery("SELECT COUNT(*) cuantas FROM mensajes");
        
        int size = 0;
        if(resulCount.next()) {
            size = resulCount.getInt(1);
        }

        // Aquí se hace la consulta
        Statement estado = con.base_datos().createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
        ResultSet resultado = estado.executeQuery("SELECT * FROM mensajes");
        
        String columns[] = {"Id", "Mensaje", "Autor", "Asunto", "Fecha"};
        String data[][] = new String[size][columns.length];

        int i = 0;
        while (resultado.next()) {
            int id = resultado.getInt("id_mensaje");
            String mensaje = resultado.getString("mensaje");
            String autor = resultado.getString("autor_mensaje");
            String asunto = resultado.getString("asunto");
            String fch = resultado.getString("fecha_mensaje");

            data[i][0] = id + "";
            data[i][1] = mensaje;
            data[i][2] = autor;
            data[i][3] = asunto;
            data[i][4] = fch;
            i++;
        }
        
        // LLamar a la tabla
        DefaultTableModel model = new DefaultTableModel(data, columns);
        JTable table = vista.tbMensajes;
        //table.doLayout();
        table.setModel(model);
        table.setShowGrid(true);
        table.setShowVerticalLines(true);
        
    }
}
