package Modelos;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class ModelInsert {
    public String asunto, mensaje, usuario;
    
    public ModelInsert(){}

    public ModelInsert(String asunto, String mensaje, String usuario) {
        this.asunto = asunto;
        this.mensaje = mensaje;
        this.usuario = usuario;
    }

    public String getAsunto() {
        return asunto;
    }

    public void setAsunto(String asunto) {
        this.asunto = asunto;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
    
    public void insertarMensaje() throws SQLException{
        Conexion conn = new Conexion();
        
        Statement estado = conn.base_datos().createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
        int resultado = estado.executeUpdate("INSERT INTO mensajes (mensaje, autor_mensaje, asunto) "
                + "VALUES ('"+this.getMensaje()+"', '"+this.getUsuario()+"', '"+this.getAsunto()+"')");
        
        if(resultado > 0){
            JOptionPane.showMessageDialog(null, "Mensaje insertado exitosamente", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
        }
        else {
            JOptionPane.showMessageDialog(null, "Problemas al insertar mensaje", "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }
}
