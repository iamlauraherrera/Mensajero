package Modelos;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class ModelBorrar {
    public int id;
    
    public ModelBorrar(){}

    public ModelBorrar(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public void borrarMensaje() throws SQLException{
        Conexion conn = new Conexion();
        
        Statement estado = conn.base_datos().createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
        int resultado = estado.executeUpdate("DELETE FROM mensajes WHERE id_mensaje="+this.getId()+"");
        
        if(resultado > 0){
            JOptionPane.showMessageDialog(null, "Mensaje borrado exitosamente", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
        }
        else {
            JOptionPane.showMessageDialog(null, "Problemas al borrar mensaje", "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }
}
