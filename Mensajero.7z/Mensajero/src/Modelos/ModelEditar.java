package Modelos;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class ModelEditar {
    public int id;
    public String asunto, mensaje;
    
    public ModelEditar(){}

    public ModelEditar(int id, String asunto, String mensaje) {
        this.id = id;
        this.asunto = asunto;
        this.mensaje = mensaje;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAsunto() {
        return asunto;
    }

    public void setAsunto(String asunto) {
        this.asunto = asunto;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
    
    public void editarMensaje() throws SQLException{
        Conexion conn = new Conexion();
        
        Statement estado = conn.base_datos().createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
        int resultado = estado.executeUpdate("UPDATE mensajes SET asunto='"+this.getAsunto()+"', mensaje='"+this.getMensaje()+"' WHERE id_mensaje="+this.getId()+"");
        
        if(resultado > 0){
            JOptionPane.showMessageDialog(null, "Mensaje actualizado exitosamente", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
        }
        else {
            JOptionPane.showMessageDialog(null, "Problemas al actualizar mensaje", "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }
}
